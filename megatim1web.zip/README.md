# megatim1web
Sistem informasi berbasis web, untuk pelaporan nilai tf siswa di nurul fikri wilayah megatim1
